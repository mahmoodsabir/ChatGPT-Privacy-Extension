document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("toggle");

  function updateToggleState() {
    chrome.storage.local.get("blurEnabled", (result) => {
      if (result.hasOwnProperty("blurEnabled")) {
        toggle.checked = result.blurEnabled;
      } else {
        chrome.storage.local.set({ blurEnabled: true }, () => {
          toggle.checked = true;
        });
      }
    });
  }

  function updateContentScript() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: "toggleBlur",
        blurEnabled: toggle.checked,
      });
    });
  }

  toggle.addEventListener("change", () => {
    chrome.storage.local.set({ blurEnabled: toggle.checked }, updateContentScript);
  });

  chrome.storage.onChanged.addListener(updateToggleState);
  updateToggleState();
});
