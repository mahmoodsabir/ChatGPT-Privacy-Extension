function toggleBlur(enabled) {
  const chatMenu = document.querySelector(".min-h-0");
  if (chatMenu) {
    if (enabled) {
      chatMenu.classList.add("blur");
    } else {
      chatMenu.classList.remove("blur");
    }
  }
}

function applyBlurWithDelay() {
  setTimeout(() => {
    chrome.storage.local.get("blurEnabled", (result) => {
      if (result.hasOwnProperty("blurEnabled")) {
        toggleBlur(result.blurEnabled);
      } else {
        chrome.storage.local.set({ blurEnabled: true }, () => {
          toggleBlur(true);
        });
      }
    });
  }, 5000);
}

applyBlurWithDelay();

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "toggleBlur") {
    toggleBlur(request.blurEnabled);
  }
});
